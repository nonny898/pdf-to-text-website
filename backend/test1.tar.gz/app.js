const express = require('express');
// const bodyParser = require('body-parser');
const multer = require('multer');

// const routes = require('./routes/index');
const upload = multer();
const app = express();

// app.use(
//   bodyParser.raw({
//     type: '*/*',
//     limit: '10mb',
//   })
// );

// app.use('/', routes);

app.post('/uploadTar', upload.any(), (req, res, nect) => {
  console.log('req.files', req.files[0].buffer.toString());

  res.status(200).end();
});

module.exports = app;
